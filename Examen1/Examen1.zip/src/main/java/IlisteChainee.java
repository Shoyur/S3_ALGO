public interface IlisteChainee {
    void ajouter(Object obj);
    void supprimer(Object obj);
    Noeud rechercher(Object obj);
    int positionDe(Object obj);
    String trouver(Object obj);
    public void afficher();    
}
