public class A_Drone extends VehiculeAerien {

    // Vehicule unVehicule;
    // private int voltage;
    // private boolean camera;
    // private int porteeKM;
    
    // public A_Drone(int voltage, boolean camera, int porteeKM) {
    //     this.unVehicule = super.clone();
    //     this.voltage = voltage;
    //     this.camera = camera;
    //     this.porteeKM = porteeKM;
    // }

    // public Vehicule getUnVehicule() {
    //     return unVehicule;
    // }

    // public void setUnVehicule(Vehicule unVehicule) {
    //     this.unVehicule = unVehicule;
    // }

    // public int getVoltage() {
    //     return voltage;
    // }

    // public void setVoltage(int voltage) {
    //     this.voltage = voltage;
    // }

    // public boolean isCamera() {
    //     return camera;
    // }

    // public void setCamera(boolean camera) {
    //     this.camera = camera;
    // }

    // public int getPorteeKM() {
    //     return porteeKM;
    // }

    // public void setPorteeKM(int porteeKM) {
    //     this.porteeKM = porteeKM;
    // }
    
    
    
}
