public class App {

    public static void main(String[] args) throws Exception {

        System.out.println("\nExécution de l'Exercice1.java :");
        Exercice1.jouer(4);

        System.out.println("\nExécution de l'Exercice2.java :");
        Exercice2.trier(10);

        System.out.println("\nExécution de l'Exercice3.java :");
        Exercice3.go();

    }

}
