import java.util.Date;

public class F_T_Auto extends F_Terrestre {
    
    private boolean pretPourHiver;
    private double volumecylindresL;
    private int nombreCylindres;
    
    public F_T_Auto(int numeroSerie, String fabricant, Date dateFabrication, String gasPneus, boolean attacheRemorque,
            double hauteurPassageLibreM, boolean pretPourHiver, double volumecylindresL, int nombreCylindres) {
        super(numeroSerie, fabricant, dateFabrication, gasPneus, attacheRemorque, hauteurPassageLibreM);
        this.pretPourHiver = pretPourHiver;
        this.volumecylindresL = volumecylindresL;
        this.nombreCylindres = nombreCylindres;
    }

    public boolean isPretPourHiver() {
        return pretPourHiver;
    }

    public void setPretPourHiver(boolean pretPourHiver) {
        this.pretPourHiver = pretPourHiver;
    }

    public double getVolumecylindresL() {
        return volumecylindresL;
    }

    public void setVolumecylindresL(double volumecylindresL) {
        this.volumecylindresL = volumecylindresL;
    }

    public int getNombreCylindres() {
        return nombreCylindres;
    }

    public void setNombreCylindres(int nombreCylindres) {
        this.nombreCylindres = nombreCylindres;
    }

    @Override
    public Date getDateFabrication() {
        // TODO Auto-generated method stub
        return super.getDateFabrication();
    }

    @Override
    public String getFabricant() {
        // TODO Auto-generated method stub
        return super.getFabricant();
    }

    @Override
    public String getGasPneus() {
        // TODO Auto-generated method stub
        return super.getGasPneus();
    }

    @Override
    public double getHauteurPassageLibreM() {
        // TODO Auto-generated method stub
        return super.getHauteurPassageLibreM();
    }

    @Override
    public int getNumeroSerie() {
        // TODO Auto-generated method stub
        return super.getNumeroSerie();
    }

    @Override
    public boolean isAttacheRemorque() {
        // TODO Auto-generated method stub
        return super.isAttacheRemorque();
    }

    @Override
    public void setAttacheRemorque(boolean attacheRemorque) {
        // TODO Auto-generated method stub
        super.setAttacheRemorque(attacheRemorque);
    }

    @Override
    public void setDateFabrication(Date dateFabrication) {
        // TODO Auto-generated method stub
        super.setDateFabrication(dateFabrication);
    }

    @Override
    public void setFabricant(String fabricant) {
        // TODO Auto-generated method stub
        super.setFabricant(fabricant);
    }

    @Override
    public void setGasPneus(String gasPneus) {
        // TODO Auto-generated method stub
        super.setGasPneus(gasPneus);
    }

    @Override
    public void setHauteurPassageLibreM(double hauteurPassageLibreM) {
        // TODO Auto-generated method stub
        super.setHauteurPassageLibreM(hauteurPassageLibreM);
    }

    @Override
    public void setNumeroSerie(int numeroSerie) {
        // TODO Auto-generated method stub
        super.setNumeroSerie(numeroSerie);
    }

}
