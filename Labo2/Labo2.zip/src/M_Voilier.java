public class M_Voilier extends VehiculeMaritime {
    
    // private int nombreChambres;
    // private int nombreVoiles;
    // private boolean moteurSecondaire;

    // public M_Voilier(int numeroSerie, String fabricant, Date dateFabrication, String couleur,
    //         boolean vesteFlotaisonFourni, int vitesseNoeudsMax, int nombreChambres, int nombreVoiles,
    //         boolean moteurSecondaire) {
    //     super(numeroSerie, fabricant, dateFabrication, couleur, vesteFlotaisonFourni, vitesseNoeudsMax);
    //     this.nombreChambres = nombreChambres;
    //     this.nombreVoiles = nombreVoiles;
    //     this.moteurSecondaire = moteurSecondaire;
    // }
    
    // public int getNombreChambres() {
    //     return nombreChambres;
    // }
    // public void setNombreChambres(int nombreChambres) {
    //     this.nombreChambres = nombreChambres;
    // }
    // public int getNombreVoiles() {
    //     return nombreVoiles;
    // }
    // public void setNombreVoiles(int nombreVoiles) {
    //     this.nombreVoiles = nombreVoiles;
    // }
    // public boolean isMoteurSecondaire() {
    //     return moteurSecondaire;
    // }
    // public void setMoteurSecondaire(boolean moteurSecondaire) {
    //     this.moteurSecondaire = moteurSecondaire;
    // }
    // @Override
    // public String getCouleur() {
    //     // TODO Auto-generated method stub
    //     return super.getCouleur();
    // }
    // @Override
    // public Date getDateFabrication() {
    //     // TODO Auto-generated method stub
    //     return super.getDateFabrication();
    // }
    // @Override
    // public String getFabricant() {
    //     // TODO Auto-generated method stub
    //     return super.getFabricant();
    // }
    // @Override
    // public int getNumeroSerie() {
    //     // TODO Auto-generated method stub
    //     return super.getNumeroSerie();
    // }
    // @Override
    // public int getVitesseNoeudsMax() {
    //     // TODO Auto-generated method stub
    //     return super.getVitesseNoeudsMax();
    // }
    // @Override
    // public boolean isVesteFlotaisonFourni() {
    //     // TODO Auto-generated method stub
    //     return super.isVesteFlotaisonFourni();
    // }
    // @Override
    // public void setCouleur(String couleur) {
    //     // TODO Auto-generated method stub
    //     super.setCouleur(couleur);
    // }
    // @Override
    // public void setDateFabrication(Date dateFabrication) {
    //     // TODO Auto-generated method stub
    //     super.setDateFabrication(dateFabrication);
    // }
    // @Override
    // public void setFabricant(String fabricant) {
    //     // TODO Auto-generated method stub
    //     super.setFabricant(fabricant);
    // }
    // @Override
    // public void setNumeroSerie(int numeroSerie) {
    //     // TODO Auto-generated method stub
    //     super.setNumeroSerie(numeroSerie);
    // }
    // @Override
    // public void setVesteFlotaisonFourni(boolean vesteFlotaisonFourni) {
    //     // TODO Auto-generated method stub
    //     super.setVesteFlotaisonFourni(vesteFlotaisonFourni);
    // }
    // @Override
    // public void setVitesseNoeudsMax(int vitesseNoeudsMax) {
    //     // TODO Auto-generated method stub
    //     super.setVitesseNoeudsMax(vitesseNoeudsMax);
    // }
}
