public class T_Camion extends VehiculeTerrestre {

    public T_Camion() {
    }
    
    // private String DieselEssence;
    // private int nombreEssieux;
    // private int chargeMaximale;
    
    // public T_Camion(int numeroSerie, String fabricant, Date dateFabrication, String gasPneus, boolean attacheRemorque,
    //         double hauteurPassageLibreM, String dieselEssence, int nombreEssieux, int chargeMaximale) {
    //     super(numeroSerie, fabricant, dateFabrication, gasPneus, attacheRemorque, hauteurPassageLibreM);
    //     DieselEssence = dieselEssence;
    //     this.nombreEssieux = nombreEssieux;
    //     this.chargeMaximale = chargeMaximale;
    // }

    // public String getDieselEssence() {
    //     return DieselEssence;
    // }

    // public void setDieselEssence(String dieselEssence) {
    //     DieselEssence = dieselEssence;
    // }

    // public int getNombreEssieux() {
    //     return nombreEssieux;
    // }

    // public void setNombreEssieux(int nombreEssieux) {
    //     this.nombreEssieux = nombreEssieux;
    // }

    // public int getChargeMaximale() {
    //     return chargeMaximale;
    // }

    // public void setChargeMaximale(int chargeMaximale) {
    //     this.chargeMaximale = chargeMaximale;
    // }

    // @Override
    // public String getGasPneus() {
    //     // TODO Auto-generated method stub
    //     return super.getGasPneus();
    // }

    // @Override
    // public double getHauteurPassageLibreM() {
    //     // TODO Auto-generated method stub
    //     return super.getHauteurPassageLibreM();
    // }

    // @Override
    // public boolean isAttacheRemorque() {
    //     // TODO Auto-generated method stub
    //     return super.isAttacheRemorque();
    // }

    // @Override
    // public void setAttacheRemorque(boolean attacheRemorque) {
    //     // TODO Auto-generated method stub
    //     super.setAttacheRemorque(attacheRemorque);
    // }

    // @Override
    // public void setGasPneus(String gasPneus) {
    //     // TODO Auto-generated method stub
    //     super.setGasPneus(gasPneus);
    // }

    // @Override
    // public void setHauteurPassageLibreM(double hauteurPassageLibreM) {
    //     // TODO Auto-generated method stub
    //     super.setHauteurPassageLibreM(hauteurPassageLibreM);
    // }

    // @Override
    // public Date getDateFabrication() {
    //     // TODO Auto-generated method stub
    //     return super.getDateFabrication();
    // }

    // @Override
    // public String getFabricant() {
    //     // TODO Auto-generated method stub
    //     return super.getFabricant();
    // }

    // @Override
    // public int getNumeroSerie() {
    //     // TODO Auto-generated method stub
    //     return super.getNumeroSerie();
    // }

    // @Override
    // public void setDateFabrication(Date dateFabrication) {
    //     // TODO Auto-generated method stub
    //     super.setDateFabrication(dateFabrication);
    // }

    // @Override
    // public void setFabricant(String fabricant) {
    //     // TODO Auto-generated method stub
    //     super.setFabricant(fabricant);
    // }

    // @Override
    // public void setNumeroSerie(int numeroSerie) {
    //     // TODO Auto-generated method stub
    //     super.setNumeroSerie(numeroSerie);
    // }

}
