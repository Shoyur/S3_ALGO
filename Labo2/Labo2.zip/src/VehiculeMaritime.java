public abstract class VehiculeMaritime extends Vehicule {

    boolean moteur;

    public void voyager() {
        
    }

}
