public abstract class VehiculeTerrestre extends Vehicule {

    String ExplosionOuElectrique;

    public void voyager() {
        
    }

}
