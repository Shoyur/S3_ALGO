public class ClientMaison {

    
    public static void main(String[] args) {
        new FabriqueMaison("bois");
        new FabriqueMaison("beton");
    }

}
