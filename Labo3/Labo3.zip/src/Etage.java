public interface Etage {

    public String getRepresentation();
    
}
