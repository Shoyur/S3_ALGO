public class EtageBeton implements Etage {

    public String getRepresentation() {
        return "étage en béton";
    }
    
}
