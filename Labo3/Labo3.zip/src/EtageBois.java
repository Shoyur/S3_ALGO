public class EtageBois implements Etage {

    public String getRepresentation() {
        return "étage en bois";
    }
    
}
