public interface Monteur {

    void construireEtage();
    void construireMurs();
    void construireToit();

}
