public interface Murs {

    public String getRepresentation();
    
}
