public class MursBeton implements Murs {

    public String getRepresentation() {
        return "murs en béton";
    }
    
}
