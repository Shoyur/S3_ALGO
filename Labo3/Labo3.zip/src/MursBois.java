public class MursBois implements Murs {

    public String getRepresentation() {
        return "murs en bois";
    }
    
}
