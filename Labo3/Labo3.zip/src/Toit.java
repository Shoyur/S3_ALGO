public interface Toit {

    public String getRepresentation();
    
}
