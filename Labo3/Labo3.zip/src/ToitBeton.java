public class ToitBeton implements Toit {

    public String getRepresentation() {
        return "toit en béton";
    }
    
}
