public class ToitBois implements Toit {

    public String getRepresentation() {
        return "toit en bois";
    }
    
}
